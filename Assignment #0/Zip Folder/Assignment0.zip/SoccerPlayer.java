// Greg Clark
// CS 23, Section #0131
// Assignment #0, Problem #1
// Prints out the salaries of varying athletes

package com.GregClark;

public class SoccerPlayer extends Athlete{
    public SoccerPlayer()
    {
        super();
        numGames = 38;
    }
    public SoccerPlayer(String n, double sal)
    {
        super(n, sal);
        numGames = 38;
    }
}
